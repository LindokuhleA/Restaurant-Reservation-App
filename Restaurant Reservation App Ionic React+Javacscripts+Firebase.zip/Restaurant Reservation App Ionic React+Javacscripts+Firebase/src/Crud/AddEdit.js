
import {
    IonApp,
    IonContent,
    IonCard,
    IonCardContent,
} from '@ionic/react'
import React, { useState, useEffect } from 'react'
import { useHistory, useParams } from 'react-router-dom'
import './AddEdit.css'
import { fireDb } from '../pages/firebaseConfig'
import { toast } from 'react-toastify'

const initialState = {
    name: "",
    surname: "",
    contact: "",
    /*status: ""*/
}

const AddEdit = () => {
    const [state, setState] = useState(initialState);
    const [data, setData] = useState({});

    const { name, surname, contact, /*status*/ } = state;

    const history = useHistory();

    const { id } = useParams();

    useEffect(() => {
        fireDb.child("contacts").on("value", (snapshot) => {
            if (snapshot.val() !== null) {
                setData({ ...snapshot.val() })
            } else {
                setData({});
            }
        })
        return () => {
            setData({})
        }
    }, [])

    useEffect(() => {
        if (id) {
            setState({ ...data[id] })
        } else {
            setState({ ...initialState })
        }

        return () => {
            setState({ ...initialState })
        }
    }, [id, data])

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!name || !surname || !contact /*|| !status*/) {
            toast.error("All feilds are required*")
        } else {
            if (!id) {
                fireDb.child("contacts").push(state, (err) => {
                    if (err) {
                        toast.error(err);
                    } else {
                        toast.success("Details successfully saved!")
                    }
                })
            } else {
                fireDb.child(`contacts/${id}`).set(state, (err) => {
                    if (err) {
                        toast.error(err);
                    } else {
                        toast.success("Details successfully Updated!")
                    }
                })
            }
            setTimeout(() => history.push('/homepage'), 2000);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setState({ ...state, [name]: value });
    };

    return (
        <IonApp>
            <IonContent fullscreen>
                <IonCard>
                    <IonCardContent>
                        <div style={{ marginTop: "100px" }}>
                            <form
                                style={{
                                    marginTop: "100px",
                                    padding: "15px",
                                    maxWidth: "400px",
                                    alignContent: "center"
                                }}
                                onSubmit={handleSubmit}
                            >
                                <b>Preserve A Table Choice: </b>
                                <br />
                                <label htmlFor="name">Name:</label>
                                <input
                                    type="text"
                                    id="name"
                                    name="name"
                                    placeholder="Type name..."
                                    value={name || ""}
                                    onChange={handleInputChange}
                                />

                                <label htmlFor="surname">Surname:</label>
                                <input
                                    type="text"
                                    id="surname"
                                    name="surname"
                                    placeholder="Type surname..."
                                    value={surname || ""}
                                    onChange={handleInputChange}
                                />

                                <label htmlFor="contact">Contact:</label>
                                <input
                                    type="number"
                                    id="contact"
                                    name="contact"
                                    placeholder="Type contact number..."
                                    value={contact || ""}
                                    onChange={handleInputChange}
                                />
                                {/* 
                                <label htmlFor="name">Status:</label>
                                <input
                                    type="text"
                                    id="status"
                                    name="status"
                                    placeholder="Your status ..."
                                    value={status || ""}
                                    onChange={handleInputChange}
                                />
                                */}
                                <input type="submit" value={id ? "Update" : "Save"} />
                            </form>
                        </div>
                    </IonCardContent>
                </IonCard>
            </IonContent>
        </IonApp>
    )
}
export default AddEdit;