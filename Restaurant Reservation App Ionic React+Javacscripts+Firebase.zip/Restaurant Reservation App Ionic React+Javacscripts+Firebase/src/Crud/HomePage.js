
import {
    IonApp,
    IonContent,
    IonCard,
    IonCardContent
} from '@ionic/react'
import React, { useState, useEffect } from 'react'
import { fireDb } from '../pages/firebaseConfig'
import { Link } from 'react-router-dom'
import './HomePage.css'
import { toast } from 'react-toastify'

const HomePage = () => {

    const [data, setData] = useState({})

    const [sortedData, setSortedData] = useState([])
    const [sort, setSort] = useState(false);

    useEffect(() => {
        fireDb.child("contacts").on("value", (snapshot) => {
            if (snapshot.val() !== null) {
                setData({ ...snapshot.val() })
            } else {
                setData({});
            }
        })
        return () => {
            setData({})
        }
    }, [])

    const onDelete = (id) => {
        if (window.confirm("Are you sure want to delete?")) {
            fireDb.child(`contacts/${id}`).remove((err) => {
                if (err) {
                    toast.error(err)
                } else {
                    toast.success("Details successfully deleted!")
                }
            })
        }
    }

    const handleChange = (e) => {
        setSort(true);
        fireDb.child("contacts").orderByChild(`${e.target.value}`)
            .on("value", (snapshot) => {
                let sortedData = [];
                snapshot.forEach((snap) => {
                    sortedData.push(snap.val())
                })
                setSortedData(sortedData);
            })
    };

    const handleReset = () => {
        setSort(false)
    };
    return (
        <IonApp>
            <IonContent fullscreen>
            {/*<IonCard>
                    <IonCardContent>*/}
                        <div style={{ marginTop: "100px" }}>
                            <table className="styled-table">
                                <thead>
                                    <tr style={{width:'100px'}}>
                                        <th style={{ textAlign: "center" }}>Table Code.</th>
                                        <th style={{ textAlign: "center" }}>Name</th>
                                        <th style={{ textAlign: "center" }}>Surname</th>
                                        <th style={{ textAlign: "center" }}>Conctact No.</th>
                                        {/*<th style={{ textAlign: "center" }}>Status</th>*/}
                                        {!sort && <th style={{ textAlign: "center" }}>Action</th>}
                                    </tr>
                                </thead>
                                {!sort && (
                                    <tbody style={{
                                        color:'red', 
                                        fontSize:'12px' }}>
                                        {Object.keys(data).map((id, index) => {
                                            return (
                                                <tr key={id}>
                                                    <th scope="row">{index + 1}</th>
                                                    <td>{data[id].name}</td>
                                                    <td>{data[id].surname}</td>
                                                    <td>{data[id].contact}</td>
                                                    {/*<td>{data[id].status}</td>*/}
                                                    <td>
                                                        <Link to={`/update/${id}`}>
                                                            <button className="btn btn-edit">Edit</button>
                                                        </Link>
                                                        <button className="btn btn-delete" onClick={() => onDelete(id)}>Delete</button>
                                                        <Link to={`/view/${id}`}>
                                                            <button className="btn btn-view">View</button>
                                                        </Link>
                                                    </td>
                                                </tr>
                                            )
                                        })}
                                    </tbody>
                                )}
                            </table>
                            {sort && (
                                <tbody>
                                    {sortedData.map((item, index) => {
                                        return (
                                            <tr key={index}>
                                                <th scope="row">{index + 1}</th>
                                                <td>{item.name}</td>
                                                <td>{item.surname}</td>
                                                <td>{item.contact}</td>
                                            </tr>
                                        )
                                    })}
                                </tbody>
                            )}
                            <label style={{color:'white'}}>Sort By:</label>
                            <select className="dropdown" name="colValue" onChange={handleChange}>
                                <option>Please Select</option>
                                <option value="name">Name</option>
                                <option value="surname">Surname</option>
                                <option value="contact">Contact</option>
                                {/*<option value="status">Status</option>*/}
                            </select>

                            <button className="btn btn-reset" onClick={handleReset}>Reset</button>
                            <br />
                        </div>
                    {/*</IonCardContent>
                </IonCard>*/}
            </IonContent>
        </IonApp>
    )
}
export default HomePage;