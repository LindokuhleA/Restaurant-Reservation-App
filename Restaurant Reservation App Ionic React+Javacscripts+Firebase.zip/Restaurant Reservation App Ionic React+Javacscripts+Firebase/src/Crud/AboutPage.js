
import {
    IonApp,
    IonCard,
    IonCardContent,
    IonContent
} from '@ionic/react'
import React from 'react'

const AboutPage = () => {
    return (
        <IonApp>
            <IonContent fullscreen>
                <IonCard>
                    <IonCardContent>
                        <div>
                            <h2>About Us</h2>
                        </div>
                    </IonCardContent>
                </IonCard>
            </IonContent>
        </IonApp>
    )
}
export default AboutPage;