
import {
    IonApp,
    IonContent,
    IonHeader,
    IonCard,
    IonCardContent
} from '@ionic/react';
import React, { useEffect, useState } from 'react'
import { Link, useLocation, useHistory } from 'react-router-dom'
import './Header.css'


const Header = () => {
    const [activeTab, setActiveTab] = useState("HomePage");
    const location = useLocation();
    const [search, setSearch] = useState("")

    const history = useHistory();

    useEffect(() => {
        if(location.pathname === "/homepage") {
            setActiveTab("HomePage")
        } else if (location.pathname === "/add") {
            setActiveTab("AddContact")
        } else if (location.pathname === "/about") {
            setActiveTab("About")
        }
    }, [location]) 

    const handleSubmit = (e) => {
        e.preventDefault();
        history.push(`/search?name=${search}`)
        setSearch("")
    }

    return (
        <IonApp>
            <IonContent>
                <IonHeader></IonHeader>
                <IonCard>
                    <IonCardContent>
                        <div className="header">
                            <p className="logo">Reserve Table</p>
                            <div className="header-right">
                                <form onSubmit={handleSubmit} style={{display: "inline"}}>
                                    <input
                                    type="text"
                                    className="inputField"
                                    placeholder="Search name ..."
                                    onChange={(e) => setSearch(e.target.value)}
                                    value={search}
                                    />
                                </form>
                                <Link to="/homepage">
                                    <p className={`${activeTab === "HomePage" ?
                                        "active" : " "}`} onClick={() => setActiveTab("HomePage")}
                                    >
                                        Home-Table
                                    </p>
                                </Link>

                                <Link to="/add">
                                    <p className={`${activeTab === "AddContact" ?
                                        "active" : " "}`} onClick={() => setActiveTab("AddContact")}
                                    >
                                        Add-User-Details
                                    </p>
                                </Link>

                                <Link to="/about">
                                    <p className={`${activeTab === "About" ?
                                        "active" : " "}`} onClick={() => setActiveTab("About")}
                                    >
                                        About-Tables
                                    </p>
                                </Link>
                            </div>
                        </div>
                    </IonCardContent>
                </IonCard>
            </IonContent>
        </IonApp>
    )
}
export default Header;