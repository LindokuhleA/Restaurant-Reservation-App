
import {
    IonApp,
    IonCard,
    IonCardContent,
    IonContent
} from '@ionic/react'

import React, {useState, useEffect } from 'react'
import { fireDb } from "../pages/firebaseConfig"
import {  useParams, Link } from 'react-router-dom'
import './View.css'

const View = () => {

    const [ user, setUser ] = useState({});

    const {id} = useParams();

    useEffect(() => {
        fireDb.child(`contacts/${id}`).get().then((snapshot) => {
            if(snapshot.exists()) {
                setUser({...snapshot.val()})
            } else {
                setUser({})
            }
        })
    },[id])

    console.log("user", user)

    return (
        <IonApp>
            <IonContent fullscreen>
                <IonCard>
                    <IonCardContent>
                        <div style={{marginTop: "100px"}}>
                            <div className="card">
                                <div className="card-header">
                                    <p>User Reservation Details</p>
                                </div>

                                <div className="container">
                                    <strong>ID: </strong>
                                    <span>{id}</span>
                                    <br />
                                    <br />
                                    <strong>Name: </strong>
                                    <span>{user.name}</span>
                                    <br />
                                    <br />
                                    <strong>Surname: </strong>
                                    <span>{user.surname}</span>
                                    <br />
                                    <br />
                                    <strong>Contact: </strong>
                                    <span>{user.contact}</span>
                                    <br />
                                    <br />
                                    <Link to="/homepage">
                                        <button className="btn btn-edit">Go Back</button>
                                    </Link>

                                    <Link to="/email">
                                        <button className="btn btn-edit">Update Profile</button>
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </IonCardContent>
                </IonCard>
            </IonContent>
        </IonApp>
    )
}
export default View;