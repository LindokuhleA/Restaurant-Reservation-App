import { Redirect, Switch, BrowserRouter, Route } from 'react-router-dom';
import { IonApp, IonRouterOutlet } from '@ionic/react';
import AboutPage from './AboutPage';
import AddEdit from './AddEdit';
import HomePage from './HomePage';
import View from './View';
import Header from './Header';
import Email from './Email';
import { ToastContainer } from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import Search from './Search';

const Main = () => {
    return (
      <IonApp>
            <Header />
            <BrowserRouter>
                <Switch>
                  <Route exact path="/homepage" component={HomePage} />
                  <Route exact path="/aboutpage" component={AboutPage} />
                  <Route exact path="/update/:id" component={AddEdit} />
                  <Route exact path="/add" component={AddEdit} />
                  <Route exact path="/view/:id" component={View} />
                  <Route exact path="/search" component={Search} />
                  <Route exact path="/email" component={Email} />
                  {/*<Route exact path="/register" render={() => <Redirect to="/register" />} />*/}
                </Switch>
            </BrowserRouter>
      </IonApp>
    )
}
export default Main;
