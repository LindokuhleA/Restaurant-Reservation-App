import {
        IonContent,
        IonCard,
        IonHeader,
        IonButton,
        IonToolbar
} from '@ionic/react'
import './Email.css'
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera'
import { useState } from 'react'

const Email: React.FC = () => {
    const [notify, setNotify] = useState("")
    const [loader, setLoader] = useState("sending...")
    const [loadbool, setLoadbool] = useState(false)
    const [info, setInfo] = useState(
        {
            email: "",
            subject: "",
            massage: "",
            media: "",
            imgName: ""
        })
    
    const handle = (event:any) => {
        var name = event.target.id
        var dictInfo = info as any
        dictInfo[name] = event.target.value
        setInfo(dictInfo)
        console.log("dictInfo", info)
    }

    const takePicture = async () => {
        setNotify("Loading image...")
        const image = await Camera.getPhoto({
            resultType: CameraResultType.Base64,
            source: CameraSource.Camera,
            quality: 100
        })

        var imageUrl = image.webPath;

        var dictInfo = info as any
        dictInfo['media'] = image.base64String
        var name = "*" + image.format + " file attached, keep safe!"
        dictInfo['imgName'] = name
        setInfo(dictInfo)
        setNotify("Image has been loaded successfully.")
        setTimeout(() => {setNotify('')}, 5000 )

        var imageElement = imageUrl;
    }

    const send = () => {
        setLoadbool(true)
        let data = new FormData()
        data.append("email", info.email);
        data.append("subject", info.subject);
        data.append("message", info.massage);
        data.append("base64", info.media);

    fetch("https://multifaceted-digest.000webhostapp.com/app.php", {
      method: "POST",
      body: data,
    })
        .then((response) => {
            response.text().then((text) => {
                if (text.includes("email was sent")) {
                    setLoader("Email successfully sent.")
                    setTimeout(() => {setLoadbool(false); setLoader("Sending...")}, 900)
                } else {
                    setLoader(text);
                    setTimeout(()=>{setLoadbool(false); setLoader("sending...")}, 1500)
                }
            });
        })
        .catch((response:string) => {
            setLoader("Oops the following error occured: " + response)
            setTimeout(() =>{setLoadbool(false); setLoader("Sending...")}, 1500)
        })
    }

    return (
        <IonContent>
            <IonHeader>
                <IonToolbar className='massageTitle'>
                    <h3>Receipt</h3>
                </IonToolbar>
            </IonHeader>
            <IonCard className="emailCard">
                { loadbool && (
                    <div className="loading">
                        <h4>{loader}</h4>
                    </div>
                )}

                <div className="mail">
                    <div className="emailInput">
                        <label htmlFor="">To: </label>
                        <input type="text" id="email" placeholder=" 123@gmail.com" name="email" onChange={(e) => {handle(e)}} />
                    </div>

                    <div>
                        <input type="text" id="email" placeholder="Receipt For Table" name="email" onChange={(e) => {handle(e)}} />
                    </div>

                    <div className="textArea">
                        <textarea onChange={(e) => {handle(e)}} placeholder="Please Provide Your Name, Surname And Contact
                        As Exact As You Provided For Reserving For A Table {Details On A View Page}
                        That Is How You Reference, Thank You Keep Receipt  Safe..." id="massage"></textarea>
                    </div>
                </div>

                <div style={{color: "black"}}>{info.imgName}. </div>

                <div className="options">
                    <button onClick={takePicture}>Take Picture</button>
                    <IonButton onClick={send}>Send</IonButton>
                </div>
            </IonCard>

            <div className="notify">{notify}</div>
        </IonContent>
    )

}
export default Email;