import { Redirect, Switch, BrowserRouter, Route } from 'react-router-dom';
import { IonApp, IonRouterOutlet } from '@ionic/react';
import { IonReactRouter } from '@ionic/react-router';
//import SignIn from './pages/SignIn/SignIn';
import Register from './pages/Register/Register';
//import Bar from './sidebar/Bar';

/* Core CSS required for Ionic components to work properly */
import '@ionic/react/css/core.css';

/* Basic CSS for apps built with Ionic */
import '@ionic/react/css/normalize.css';
import '@ionic/react/css/structure.css';
import '@ionic/react/css/typography.css';

/* Optional CSS utils that can be commented out */
import '@ionic/react/css/padding.css';
import '@ionic/react/css/float-elements.css';
import '@ionic/react/css/text-alignment.css';
import '@ionic/react/css/text-transformation.css';
import '@ionic/react/css/flex-utils.css';
import '@ionic/react/css/display.css';

/* Theme variables */
import './theme/variables.css';

import Home1 from './SideBar/Home1'
import { Menu } from './SideBar/Menu';
import PageOne from './SideBar/PageOne';
import PageTwo from './SideBar/Page';
import AboutUs from './SideBar/AboutUs';
import Location from './SideBar/Location';
import Picture from './Camera/Picture';
import { Component } from "react";
import { auth, db } from "./pages/firebaseConfig"
import SignIn from './pages/SignIn/SignIn';
import Main from './Crud/Main';

{/* 
import AboutPage from './Crud/subHolder/AboutPage';
import AddEdit from './Crud/subHolder/AddEdit';
import HomePage from './Crud/subHolder/HomePage';
import View from './Crud/subHolder/View';
import Header from './Crud/holder/Header';
*/}
/*import { ToastContainer } from "react-toastify"
import "react-toastify/dist/ReactToastify.css"*/

class App extends Component<any, any>{
  constructor(props: any) {
    super(props);

    this.state = {
      loggedIn: null,
      userData: {},
      firebaseUser: {},
      registerData: null,
      bookingsData: null
    }
  }

  componentDidMount = () => {
    console.log("App mounted")
    auth.onAuthStateChanged((user) => {
      if (user) {
        console.log("user logged In")
        window.alert("User has successfully Logged In.")
        //console.log(user);

        this.setState({
          firebaseUser: user,
          loggedIn: true
        }, this.finishSignUpSignIn)

      } else {
        console.log("user is not logged in")
        // window.alert("Please sign in, if you got no account Sign Up now.")
        this.setState({
          firebaseUser: {},
          loggedIn: false
        })
      }
    })
  }

  saveBookingsData = (data: any) => {
    this.setState({
      bookingsData: data
    }, () => console.log(this.state.bookingsData))
  }

  saveUpBookings = () => {

    if (this.state.bookingsData !== null) {

      var uid = this.state.firebaseUser.uid

      db.collection("userData")
        .doc(uid)
        .set({
          startDate: this.state.bookingsData.startDate,
          startTime: this.state.bookingsData.startTime,
          endTime: this.state.bookingsData.endTime,
          table: this.state.bookingsData.table,
          items: []
        })
        .then(() => {
          console.log("Bookings has been added")
          window.alert("Bookings Detials Has Been Successfully Recieved Thanks, Looking Forward To Have You!")
          this.setState({
            bookingsData: null
          })
        })
        .catch((error) => {
          console.error("Ooops! Something Went Wrong (: Try Again ", error)
          window.alert(error)
        })
    }
  }


  saveRegisterData = (data: any) => {
    this.setState({
      registerData: data
    }, () => console.log(this.state.registerData))
  }

  finishSignUpSignIn = () => {

    this.connectCurrentUser();

    if (this.state.registerData !== null) {

      var uid = this.state.firebaseUser.uid

      db.collection("userData").doc(uid).set({
        nameRegister: this.state.registerData.nameRegister,
        surnameRegister: this.state.registerData.surnameRegister,
        cellphoneRegister: this.state.registerData.cellphoneRegister,
        usernameRegister: this.state.registerData.usernameRegister,
        emailRegister: this.state.registerData.emailRegister,
        passwordRegister: this.state.registerData.passwordRegister,
        confirmPwdRegister: this.state.registerData.confirmPwdRegister,
        items: []
      })
        .then(() => {
          console.log("User details have been added on the firestore")
          window.alert("User Details Have Been Recorded")
          this.setState({
            registerData: null
          })
        })
        .catch((error) => {
          console.error("Error Typing, Try Again: ", error)
          window.alert(error)
        })
    }

  }
  connectCurrentUser = () => {
    var uid = this.state.firebaseUser.uid;

    var connectionFunction = db.collection("userData").doc(uid)
      .onSnapshot((doc) => {
        console.log("Current User Data Updated: ", doc.data())
        this.setState({
          userData: doc.data(),
          connectionFunction: connectionFunction
        })
      })
  }
  render() {
    return (
      <IonApp>
        <IonReactRouter>
          <Menu />
          <IonRouterOutlet id="main">
            <Route exact path="/signin"> {/*component={Home1}> */}
              <SignIn appState={this.state} />
            </Route>

            <Route exact path="/register"> {/*component={Register} />*/}
              <Register saveRegisterData={this.saveRegisterData} appState={this.state} />
            </Route>

            <Route exact path="/home1"> {/*component={Home1} />*/}
              <Home1 appState={this.state} />
            </Route>

            <Route exact path="/page-1">  {/*component={PageOne} />*/}
              <PageOne saveBookingsData={this.saveBookingsData} appState={this.state} />
            </Route>
            <Route exact path="/page-2" component={PageTwo} />
            <Route exact path="/page-3" component={AboutUs} />

            

            <Route exact path="/" render={() => <Redirect to="/signin" />} />

            <Route exact path="/picture" component={Picture} />

            {/* 
            <IonRouterOutlet>
              <IonBrowserRouter>
                <Route exact path="/aboutpage" component={AboutPage} />
              </IonBrowserRouter>
            </IonRouterOutlet>
            */}

            {/*
            <Header />
            <BrowserRouter>
              <IonRouterOutlet>
                <Switch>
                  <Route exact path="/picture" component={Picture} />

                  <Route exact path="/homepage" component={HomePage} />
                  <Route exact path="/aboutpage" component={AboutPage} />
                  <Route exact path="/update/:id" component={AddEdit} />
                  <Route exact path="/add" component={AddEdit} />
                  <Route exact path="/view/:id" component={View} />
                  <Route exact path="/register" render={() => <Redirect to="/register" />} />
                </Switch>
              </IonRouterOutlet>
            </BrowserRouter>
            */}
            <Main />
          </IonRouterOutlet>
        </IonReactRouter>
      </IonApp>
    )
  }
}
export default App;
