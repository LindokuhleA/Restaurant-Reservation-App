import React from 'react';
import {
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
  IonInput,
  IonItem,
  IonIcon,
  IonLabel,
  IonButton,
  IonFooter,
  IonLoading
} from '@ionic/react';

import {
  enterOutline,
  mailOpenOutline,
  callOutline,
  chatbubbleOutline,
  lockClosedOutline,
  keyOutline
} from 'ionicons/icons';
import './Register.css';
import { Component, useState } from "react"
import { auth, db } from "../firebaseConfig"
import { Redirect } from "react-router-dom"

class Register extends Component<any, any> {
  constructor(props: any) {
    super(props);

    this.state = {
      nameRegister: "",
      surnameRegister: "",
      emailRegister: "",
      cellphoneRegister: "",
      usernameRegister: "",
      passwordRegister: "",
      confirmPwdRegister: "",
    }
  }

  handleChange = (e: any) => {
    var value = e.target.value;
    var id = e.target.id;

    this.setState({
      [id]: value
    }, () => { console.log(this.state) })
  }

  componentDidMount = () => {
    console.log("Home paper mounted")
  }

  handleRegister = () => {
    //console.log(this.state)

    this.props.saveRegisterData(this.state);

    var email = this.state.emailRegister;
    var password = this.state.passwordRegister;
    auth.createUserWithEmailAndPassword(email, password)
      .then((userCredentail) => {
        //var user = userCredentail.user;
        console.log("user created thanks")
        window.alert("Account Registerd, You Auto Logged In.")
      })
      .catch((error) => {
        var errorCode = error.code;
        var errorMessage = error.message;
        console.log(error.code);
        console.log(error.message)
        //window.alert(error.code)
        //window.alert(error.message)
      })
  }

  render() {
    if (this.props.appState.loggedIn == null) {
      return (
        <div></div>
      )
    } else if (this.props.appState.loggedIn == true){
      return (
        <Redirect to="/signin"></Redirect>
      )
    }
    else {
      return (
        <IonPage>
          <IonContent fullscreen>
            <IonHeader>
              <IonToolbar>
                <IonTitle></IonTitle>
              </IonToolbar>
            </IonHeader>
            <div className="login-section ion-padding">
              <div className="heading ion-padding">
                <b className="heading ion-padding"> CREATE ACCOUNT!</b>
                
              </div>

              {/*<IonLoading message="processing..." duration={0} isOpen={busy}>*/}

              <div className="login-form ion padding">
                <div className="form-input">
                  <IonItem>
                    {/* <IonLabel position="floating">Name</IonLabel> */}
                    <IonInput
                      id="nameRegister"
                      type="text"
                      placeholder="First name"
                      value={this.state.nameRegister}
                      onIonChange={this.handleChange} />
                    <IonIcon size="default" icon={enterOutline} />
                  </IonItem>
                </div>

                <div className="form-input">
                  <IonItem>
                    {/* <IonLabel position="floating">Surname</IonLabel> */}
                    <IonInput
                      id="surnameRegister"
                      type="text"
                      placeholder="Surname"
                      value={this.state.surnameRegister}
                      onIonChange={this.handleChange} />
                    <IonIcon size="default" icon={enterOutline} />
                  </IonItem>
                </div>

                <div className="form-input">
                  <IonItem>
                    {/* <IonLabel position="floating">Email</IonLabel> */}
                    <IonInput
                      id="emailRegister"
                      type="email"
                      placeholder="Email address"
                      value={this.state.emailRegister}
                      onIonChange={this.handleChange} />
                    <IonIcon size="default" icon={mailOpenOutline} />
                  </IonItem>
                </div>

                <div className="form-input">
                  <IonItem>
                    {/* <IonLabel position="floating">Cellphone</IonLabel> */}
                    <IonInput
                      id="cellphoneRegister"
                      type="number"
                      placeholder="Phone number"
                      value={this.state.cellphoneRegister}
                      onIonChange={this.handleChange} />
                    <IonIcon size="default" icon={callOutline} />
                  </IonItem>
                </div>

                <div className="form-input">
                  <IonItem>
                    {/* <IonLabel position="floating">Username</IonLabel> */}
                    <IonInput
                      id="usernameRegister"
                      type="text"
                      placeholder="Username"
                      value={this.state.usernameRegister}
                      onIonChange={this.handleChange} />
                    <IonIcon size="default" icon={chatbubbleOutline} />
                  </IonItem>
                </div>

                <div className="form-input">
                  <IonItem>
                    {/* <IonLabel position="floating">Password</IonLabel> */}
                    <IonInput
                      id="passwordRegister"
                      type="password"
                      placeholder="Password"
                      value={this.state.passwordRegister}
                      onIonChange={this.handleChange} />
                    <IonIcon size="default" icon={lockClosedOutline} />
                  </IonItem>
                </div>

                <div className="form-input">
                  <IonItem>
                    {/* <IonLabel position="floating">Confirm</IonLabel> */}
                    <IonInput
                      id="confirmPwdRegister"
                      type="password"
                      placeholder="Confirm password"
                      value={this.state.confirmPwdRegister}
                      onIonChange={this.handleChange} />
                    <IonIcon size="default" icon={keyOutline} />
                  </IonItem>

               

                </div>
                <div className="action-buttons ion-padding">
                <IonButton onClick={this.handleRegister} size="large" className="login-button" /*routerLink="/home1"*/>create</IonButton>
              </div>
              </div>
            </div>
            
          </IonContent>
        </IonPage>
      )
    }
  }
}
export default Register;
