import firebase from "firebase/app"
import "firebase/auth"
import "firebase/firestore"
import "firebase/database"

export const firebaseConfig = {
    apiKey: "AIzaSyD4QpSCG1Wk0I_IvtH-kLAmYwJWGni3sPA",
    authDomain: "fmmzansitogo.firebaseapp.com",
    projectId: "fmmzansitogo",
    storageBucket: "fmmzansitogo.appspot.com",
    messagingSenderId: "338490616472",
    appId: "1:338490616472:web:603f9779ce355c10593eed",
    measurementId: "G-KHE01ZKESG"
}
firebase.initializeApp(firebaseConfig)
export const fireDb = firebase.database().ref();
//export const fireDb = firebase.firestore();
export const auth = firebase.auth();
export const db = firebase.firestore();


/*
var Configfire = {
    apiKey: "AIzaSyDnyTGFT6M-OckdJP0qns3g7KkY4e7m8rc",
    authDomain: "khanyiemzansitogo.firebaseapp.com",
    databaseURL: "https://khanyiemzansitogo-default-rtdb.firebaseio.com",
    projectId: "khanyiemzansitogo",
    storageBucket: "khanyiemzansitogo.appspot.com",
    messagingSenderId: "686808508553",
    appId: "1:686808508553:web:99f2b374c32c841132fe58",
    measurementId: "G-GR3PQJQ503"
}
const fireDb = firebase.initializeApp(Configfire);
export default fireDb.database().ref();
**/
