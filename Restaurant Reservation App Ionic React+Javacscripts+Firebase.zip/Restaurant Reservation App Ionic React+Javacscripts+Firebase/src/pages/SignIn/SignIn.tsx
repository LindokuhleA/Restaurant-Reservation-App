
import React from 'react';
import {
  IonContent,
  IonPage,
  IonInput,
  IonItem,
  IonLabel,
  IonButton,
  IonIcon,
  IonLoading
} from '@ionic/react';

import {
  lockClosedOutline,
  mailOutline
} from 'ionicons/icons'
import './Home.css';
import { Component } from "react"
import { auth, db } from "../firebaseConfig"
import { Redirect } from 'react-router-dom';

class SignIn extends Component<any, any> {
  constructor(props: any) {
    super(props);

    this.state = {
      emailSignIn: "",
      passwordSignIn: "",
      //loggedIn: null
    }
  }

  handleChange = (e: any) => {
    var value = e.target.value;
    var id = e.target.id;
    //console.log(id, value)

    this.setState({
      [id]: value
    }, () => { console.log(this.state) })
  }

  componentDidMount = () => {
    console.log("Login page mounted")
  }

  handleSignin = () => {
    var email = this.state.emailSignIn;
    var password = this.state.passwordSignIn;

    auth.signInWithEmailAndPassword(email, password)
      .then((userCredential) => {
        //var user = userCredential.user;
        console.log("User has logged in")
      })
      .catch((error) => {
        //var errorCode = error.code;
        //var errorMessage = error.message;
        console.log(error.code);
        console.log(error.message);
      })
  }

  render() {
    if (this.props.appState.loggedIn == null) {
      return (
        <div></div>
      )}
      else if (this.props.appState.loggedIn == true){
        return (
          <Redirect to="/home1" />
        )
      }
      else {
        return (
          <IonPage>
            <IonContent fullscreen>
              <div className="login-section ion-padding">
                <div className="heading ion-padding">
                  {/* <h1>Welcome To MzansiToGo App!</h1> */}
                  <p>Please log in or create an account to continue.</p>
                </div>
                {/*<IonLoading message="Loading..." duration={0} isOpen={busy} //{busy} />*/}
                <div className="login-form">
                  <div className="form-input">
                    <IonItem>
                      {/* <IonLabel position="floating">Email</IonLabel> */}
                      <IonInput
                        id="emailSignIn"
                        type="email"
                        placeholder="Email address or username"
                        value={this.state.emailSignIn}
                        onIonChange={this.handleChange} />
                      <IonIcon icon={mailOutline} />
                    </IonItem>
                  </div>
    
                  <div className="form-input">
                    <IonItem>
                      {/* <IonLabel position="floating">Password</IonLabel> */}
                      <IonInput
                        id="passwordSignIn"
                        type="password"
                        placeholder="Password"
                        value={this.state.passwordSignIn}
                        onIonChange={this.handleChange} />
                      <IonIcon icon={lockClosedOutline} />
                    </IonItem>
                  </div>
                </div>

                <div className="action-buttons ion-padding">
                  <br/>
                  <IonButton onClick={this.handleSignin} size="default" className="login-button" /*routerLink="/home1"*/ >Log in</IonButton>
                  <p>Don't have an existing account? <br/> Sign Up.</p>
                  <IonButton size="default" className="signup-button"
                    fill="outline" routerLink="/register">Sign Up</IonButton>
                    <br/>
                    <br/>
                  <a href="http://">Forgot Password?</a>
                  {/* <IonButton size="default" className="forget-button" routerLink="">Click</IonButton> */}
                </div>
              </div>
            </IonContent>
          </IonPage >
        )
      }
    }
  }
export default SignIn;