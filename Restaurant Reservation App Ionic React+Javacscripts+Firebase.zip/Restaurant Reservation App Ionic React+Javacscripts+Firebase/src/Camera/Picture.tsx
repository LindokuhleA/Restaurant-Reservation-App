import {
    IonContent,
    IonHeader,
    IonPage,
    IonTitle,
    IonToolbar,
    IonButtons,
    IonButton,
    IonIcon,
    IonCard
} from '@ionic/react'
import React from 'react'
import { 
    cameraOutline,
    manOutline
} from 'ionicons/icons'
import { Camera, CameraResultType } from '@capacitor/camera'

const Pic: React.FC = () => {

    const takePicture = async () => {
        const image = await Camera.getPhoto( {
            quality: 3000,
            allowEditing: true,
            resultType: CameraResultType.Base64
        } )
        var imageUrl = image.webPath;
        //imageElement.src = imageUrl;
    }

    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle><IonIcon size="large" icon={manOutline} />User</IonTitle>
                <IonButtons slot="end">
                    <IonButton onClick={() => takePicture()}>Take Photo: :
                        <IonIcon size="large" icon={cameraOutline}></IonIcon>
                    </IonButton>
                </IonButtons>
                </IonToolbar>
            </IonHeader>
            <IonContent className="ion-padding">
                {/*
                    image ? (
                        <div>
                            <pre>{JSON.stringify(image, null,2)}</pre>
                            <IonCard>
                                <img src={image.Url || image.webPath} />
                            </IonCard>
                        </div>
                    ) : null
                    */
                }
            </IonContent>
        </IonPage>
    )
}
export default Pic;


/*
{availableFeatures.getPhoto ? (
                <div>
                    <div><IonButton onClick={takePicture}>Take Photo</IonButton></div>
                    <div>{photo && <img alt="" src={photo.dataUrl} />} </div>
                </div>
                ) : <div>Camera not available on this platform</div>}

*/

/*
    {availableFeatures.getPhoto ? (
                <div>
                    <pre>{JSON.stringify(photo,null,2)}</pre>
                    <IonCard>
                        <img src={photo.dataUrl || photo.webPath} />
                    </IonCard> 
                </div> ) : null}
*/