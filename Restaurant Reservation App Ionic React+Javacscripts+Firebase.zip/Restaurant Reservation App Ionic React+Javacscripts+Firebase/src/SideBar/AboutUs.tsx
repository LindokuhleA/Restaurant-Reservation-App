import { 
    IonHeader, 
    IonToolbar, 
    IonContent, 
    IonPage, 
    IonTitle, 
    IonButton,
    IonIcon,
    IonItem
} from "@ionic/react"
import React from 'react'
import { NavButton } from './NavButton'

import { informationOutline } from "ionicons/icons"

const AboutUs: React.FC = () => {
    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>About Us</IonTitle>
                    <IonButton slot="end">
                        <IonIcon size="default" icon={informationOutline}/>
                        <NavButton />
                    </IonButton>
                </IonToolbar>
            </IonHeader>
            <IonContent fullscreen>
                <div style={{
                    textAlign : 'center', 
                    marginTop: '5%',
                    backgroundColor: 'white',
                    borderRadius: '5%',
                    bottom: '2px',
                    position: 'fixed',
                    right: '0',
                    left: '0',
                    borderTopLeftRadius: '20px',
                    borderTopRightRadius: '20px',
                    borderBottomLeftRadius: '10px',
                    borderBottomRightRadius: '10px',


                    
                }}>







                    <br />
                    <h3>MzansiToGo.</h3>
                    <IonItem></IonItem>
                    
                    <h5> We love providing assintance to restuarant <br/> and all their customers.
                    <br /> We love what we do.
                    <br /> We provide our service the best <br /> possible way we can
                    </h5>
                    <IonItem></IonItem>
                    <h3>Our Story</h3>
                    <p>The world is already evolving, <br /> 
                    so this mobile app will add that introduce AI which <br />
                    will allow customers to easily reserve a table <br />
                    at any restuarant. <br />

                    The mobile app will help avoid miscommunication <br />
                    when having to find a <br /> seat/table at the restuarant.
                    <br />
                    This mobile app will help reduce time consuming <br /> for both customers and managers.
                    <IonItem></IonItem>
                    <br />
                    </p>
                </div>
            </IonContent>
        </IonPage>
    )
}
export default AboutUs;