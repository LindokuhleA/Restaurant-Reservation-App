import {
    IonContent,
    IonCard,
    IonHeader,
    IonCardHeader,
    IonPage,
    IonRow,
    IonCol,
    IonTitle,
    IonToolbar,
    IonButton,
    IonFooter,
    IonIcon,
    IonText,
    IonCardContent,
} from '@ionic/react'
import React from 'react'
import './styling.css';
// import { Swiper, SwiperSlide } from 'swiper/react';
import { NavButton } from './NavButton'
import { homeOutline } from 'ionicons/icons'
import { Component } from 'react'
import { auth } from '../pages/firebaseConfig';



class Home extends Component<any, any>{
    constructor(props: any) {
        super(props);
    }

    handleSignOut = () => {
      this.props.appState.connectionFunction();

      auth.signOut().then(() => {
        console.log("Sign Up")
      })
      .catch((error) => {
        console.log(error)
      })
    }
    componentDidMount = () => {
      console.log("")
    }
    render() {
        // //var items = this.props.appState.userData.items;
        // var nameRegister = this.props.appState.userData.nameRegister
        // var surnameRegister = this.props.appState.userData.surnameRegister

        return (
            <IonPage>
                <IonContent>
                  {/* <IonCard>
                    <IonCardContent>
                      <div style={{textAlign:'center', color:'black', marginTop:'5%', marginBottom:'2%', fontWeight:'bold'}}>
                        Hello {nameRegister} {surnameRegister},
                        <br/>
                        Thank you for using our App!
                      </div>
                    </IonCardContent>
                  </IonCard> */}
                    <div className='top ion-padding'>
                        <div className='Nav'>
                        <IonToolbar className='tool'>
                        <IonButton slot="end">
                            <IonIcon size="default" icon={homeOutline} />
                            <NavButton />
                        </IonButton><IonTitle><button className="signOut"onClick={this.handleSignOut}>Sign Out</button></IonTitle>
                        </IonToolbar>
                        <h1 className='heading-1'>MzansiToGo</h1>
                        </div>
                        </div>
                    
            
                    
                    <div style={{backgroundColor: 'white'}}className='bottom-section ion-padding'>
                    <IonText>
                       <h1 className='h1'> Reserve, Sit and Go</h1>
                       <h3 className='h3'> Resturant reservations made easier</h3>
                    </IonText>
                   
                    <div className='pictures'>
                        <IonRow>
                        <IonCol size='4'>
                            <img src='../assets/images/image1.jpeg' alt='' />
                       
                       </IonCol> 

                       <IonCol size='4'>
                            <img src='../assets/images/image2.jpeg' alt='' />
                       
                       </IonCol> 

                       <IonCol size='4'>
                            <img src='../assets/images/image3.jpeg' alt='' />
                       
                       </IonCol> 
                       </IonRow>
                      </div>  
                     
                     <div className='images ion-padding'>
                            <div>
                                <h1 className='heading'> Breakfast the most important meal of the day   </h1>
                              <IonText className='text'> Looking for a healthy refreshing meal in the morning look no further we got you covered a breakfast filled with essential vitamins and minerals.  </IonText>
                            </div>
                            <IonRow>
                              <img className='break' src='../assets/images/image4.jpg' alt='' />
                            </IonRow>
                   </div>
                   <div className='images ion-padding'>
                            <div>
                                <h1 className='heading'>Lunch time meals enjoyed in less the time </h1>
                              <IonText className='text'> If your lunch hour is starting to feel a little stale or exhausting, book a one tables and come and enjoy a filling lunch we always keep things fresh and simple.  </IonText>
                            </div>
                            <IonRow>
                              <img className='break' src='../assets/images/image5.jpg' alt='' />
                            </IonRow>
                   </div>
                   <div className='images ion-padding'>
                            <div>
                                <h1 className='heading'>Late night dinner dates , MzansiToGo is the place to Go</h1>
                              <IonText className='text'> If you're stuck at home , bored and hungry schedule a late-night dinner with us you wont regret it  </IonText>
                            </div>
                            <IonRow>
                               <img className='break' src='../assets/images/image7.jpg' alt='' />
                            </IonRow>
                   </div>
                   
                   
                    </div>

                    <div>
                
                  <IonButton size="default" className="Button"
                     routerLink="/page-1">Book Now</IonButton>
                 
                 </div>
               </IonContent>
            </IonPage>
        )
    }
}
export default Home;