import { IonButton, IonMenuButton } from '@ionic/react'
import React, { useEffect } from 'react'

export const NavButton = () => {
    const [ mQuery, setMQuery ] = React.useState<any>({
        matches: window.innerWidth > 768 ? true : false
    })

    useEffect(() => {
        window.matchMedia("(min-width: 768px)").addListener(setMQuery);
    },[])

    console.log(mQuery.matches);

    return (
        <div>
            {mQuery && !mQuery.matches ? (
            <IonMenuButton />

            ) : (
            <>
            <IonButton routerLink={'/home1'} > Home </IonButton> 
            <IonButton routerLink={'/page-1'} > Booking </IonButton>
            <IonButton routerLink={'/page-2'} > Contact </IonButton>
            <IonButton routerLink={'/page-3'} > About Us </IonButton>
           
            </>
            )}
        </div>
    );
}; 