import { 
    IonHeader, 
    IonToolbar, 
    IonContent, 
    IonPage, 
    IonTitle, 
    IonButton,
    IonIcon
} from "@ionic/react"
import { NavButton } from './NavButton'
import { informationOutline } from "ionicons/icons"
import React, { Component } from "react"

class Location extends Component<any, any> {
    constructor(props: any) {
        super(props);
    }
    render() {
        return (
            <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>Location</IonTitle>
                    <IonButton slot="end">
                        <IonIcon size="default" icon={informationOutline}/>
                        <NavButton />
                    </IonButton>
                </IonToolbar>
            </IonHeader>
            <IonContent fullscreen>

            </IonContent>
        </IonPage>
        )
    }
}
export default Location;
