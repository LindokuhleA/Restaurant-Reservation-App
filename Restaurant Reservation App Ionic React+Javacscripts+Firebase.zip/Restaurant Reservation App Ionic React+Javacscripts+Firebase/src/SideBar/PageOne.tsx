import {
    IonContent,
    IonHeader,
    IonPage,
    IonTitle,
    IonToolbar,
    IonButton,
    IonIcon,
    IonList,
    IonItem,
    IonInput,
    IonLabel,
    IonDatetime,
    IonSelect,
    IonSelectOption
} from '@ionic/react'
import React from 'react'
import { NavButton } from './NavButton'
//import  Fmfile  from './Fmfile'
import { bookOutline } from 'ionicons/icons'
import { Component } from "react"
import { db } from "../pages/firebaseConfig"

class PageOne extends Component<any, any> {
    constructor(props: any) {
        super(props);

        this.state = {
            startDate: "2021-01-1",
            startTime: "2021-08-19T07:43Z",
            endTime: "2021-012-30",
            table: "Sets"
        }
    }

    handleChange = (e: any) => {
        var value = e.target.value;
        var id = e.target.id;

        this.setState({
            [id]: value
        }, () => { console.log(this.state) })
    }

    handleBookings = () => {
        this.props.saveBookingsData(this.state)
        /*
        var currentItems = this.state.appState.userData.items

        currentItems.push(this.state.startDate)
        currentItems.push(this.state.startTime)
        currentItems.push(this.state.endTime)
        currentItems.push(this.state.table)
        */

        var uid = this.props.appState.firebaseUser.uid;

        var docRef = db.collection("userData").doc(uid);

        docRef.update({
            items: true,
        })
        .then(() => {
            console.log("Bookings details been updated:");
            window.alert("Bookings details been updated:")
        })
        .catch((error) => {
            console.error("Ooops, something went wrong!", error);
            window.alert(error)
        })
    }
    render() {
        //var items = this.props.appState.userData.items
        return (
            <IonPage>
                <IonHeader>
                    <IonToolbar>
                        <IonTitle>Bookings</IonTitle>
                        <IonButton slot='end'>
                            <IonIcon size="default" icon={bookOutline} />
                            <NavButton />
                        </IonButton>
                    </IonToolbar>
                </IonHeader>,
                
                <IonHeader >
                    {/* <IonToolbar color="primary">
                        <IonTitle>BOOKING App</IonTitle>
                    </IonToolbar> */}
                </IonHeader>
                <IonContent fullscreen>
                    {/*<Fmfile />*/}
                    <IonList>
                        <IonItem className="IonInput">
                            <IonInput
                                placeholder="SELECT DATE & TIME FOR THE RESERVATION"
                                onIonChange={this.handleChange}></IonInput>
                        </IonItem>

                        <IonItem></IonItem>

                        <IonItem>
                            <IonLabel>Start Date</IonLabel>
                            <IonDatetime
                                id="startDate"
                                value={this.state.startDate}
                                /*value="2021-01-1"*/
                                placeholder="Select Date"
                                onIonChange={this.handleChange}
                            >

                            </IonDatetime>
                        </IonItem>

                        <IonItem>
                            <IonLabel>Start Time</IonLabel>
                            <IonDatetime id="startTime"
                                display-format="HH:MM"
                                picker-format="HH:MM"
                                value={this.state.startTime}
                                /*value="2021-08-19T07:43Z"*/
                                onIonChange={this.handleChange}
                            >

                            </IonDatetime>
                        </IonItem>

                        <IonItem>
                            <IonLabel>Ends</IonLabel>
                            <IonDatetime id="endTime"
                                /*value="2021-012-30"*/
                                value={this.state.endTime}
                                placeholder="Select Date"
                                onIonChange={this.handleChange}
                            >

                            </IonDatetime>
                        </IonItem>

                        <IonItem>
                            <IonLabel>Select Number Of People: </IonLabel>
                            <IonSelect /*value="Sets"*/
                                value={this.state.table}
                                id="table"
                                onIonChange={this.handleChange}>
                                <IonSelectOption value="1">1</IonSelectOption>
                                <IonSelectOption value="2">2</IonSelectOption>
                                <IonSelectOption value="3">3</IonSelectOption>
                                <IonSelectOption value="4">4</IonSelectOption>
                                <IonSelectOption value="5">5</IonSelectOption>
                                <IonSelectOption value="5">6</IonSelectOption>
                            </IonSelect>
                        </IonItem>
                    </ IonList>
                    <div className="action-buttons ion-padding">
                        <IonButton onClick={this.handleBookings} size="default"
                            className="login-button">
                                Update
                            </IonButton>
                    </div>

                    <div className="action-buttons ion-padding">
                        <b style={{
                            color: 'skyblue',
                            fontSize: '20px'
                        }}>
                            If you wish to make an view, edit, update or delete, <br />
                            please click below.
                        </b> <br />
                        <br />
                        <a href='/add' className='link'>Update...Click Me</a>
                    </div>
                </IonContent>
            </IonPage>
        )
    }
}
export default PageOne;