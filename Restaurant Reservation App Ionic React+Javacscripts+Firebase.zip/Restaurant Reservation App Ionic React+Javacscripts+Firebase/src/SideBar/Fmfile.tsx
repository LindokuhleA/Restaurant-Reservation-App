import {
  IonApp,
  IonLabel,
  IonTitle,
  IonHeader,
  IonToolbar,
  IonContent,
  IonItem,
  IonDatetime,
  IonList,
  IonInput,
  IonSelect,
  IonSelectOption,
  IonButton,
} from "@ionic/react"
import { Component } from "react"
import { auth, db } from "../pages/firebaseConfig"

class Fmfile extends Component<any, any> {
  constructor(props: any) {
    super(props);

    this.state = {
      startDate: "2021-01-1",
      startTime: "2021-08-19T07:43Z",
      endTime: "2021-012-30",
      table: "Sets"
    }
  }

  componentDidMount = () => {
    console.log("Bookings Amounted")
  }

  handleChange = (e: any) => {
    var value = e.target.value;
    var id = e.target.id;

    this.setState({
      [id]: value
    }, () => {console.log(this.state)})
  }

  handleBookings = () => {
    //console.log(this.state.appState.userData.items)
    //this.props.saveBookingsData(this.state);
    
  }

  render() {
    var items = this.props.appState.userData.itmes;
    return (
      <IonApp>
        <IonHeader >
          <IonToolbar color="primary">
            <IonTitle>BOOKING App</IonTitle>
          </IonToolbar>
        </IonHeader>,
        <IonContent className="main">

          <IonList>
            <IonItem className="IonInput">
              <IonInput 
              placeholder="SELECT DATE & TIME FOR THE RESERVATION"
              onIonChange={this.handleChange}></IonInput>
            </IonItem>

            <IonItem></IonItem>

            <IonItem>
              <IonLabel>Start Date</IonLabel>
              <IonDatetime 
              id="startDate" 
              value={this.state.startDate}
              /*value="2021-01-1"*/
               placeholder="Select Date"
               onIonChange={this.handleChange}
               >

               </IonDatetime>
            </IonItem>

            <IonItem>
              <IonLabel>Start Time</IonLabel>
              <IonDatetime id="startTime"
              display-format="MMM DD, YYYY, HH:MM" 
              picker-format="MMM DD, YYYY, HH:MM" 
              value={this.state.startTime}
              /*value="2021-08-19T07:43Z"*/
              onIonChange={this.handleChange}
              >

              </IonDatetime>
            </IonItem>

            <IonItem>
              <IonLabel>Ends</IonLabel>
              <IonDatetime id="endTime" 
              /*value="2021-012-30"*/
              value={this.state.endTime}
              placeholder="Select Date"
              onIonChange={this.handleChange}
              >

              </IonDatetime>
            </IonItem>

            <IonItem>
              <IonLabel>Select Number Of People: </IonLabel>
              <IonSelect /*value="Sets"*/ 
              value={this.state.table} 
              id="table"
              onIonChange={this.handleChange}>
                <IonSelectOption value="1">1</IonSelectOption>
                <IonSelectOption value="2">2</IonSelectOption>
                <IonSelectOption value="3">3</IonSelectOption>
                <IonSelectOption value="4">4</IonSelectOption>
                <IonSelectOption value="5">5</IonSelectOption>
                <IonSelectOption value="5">6</IonSelectOption>
              </IonSelect>
            </IonItem>
          </ IonList>
          <div className="action-buttons ion-padding">
            <IonButton onClick={this.handleBookings} size="large"
              className="login-button">Submit</IonButton>
          </div>
        </IonContent>
      </IonApp>
    )
  }
}
export default Fmfile;