
import { IonFab, IonFabButton, IonFabList } from '@ionic/react';
import { shareSocialOutline, logoYoutube, logoFacebook, logoInstagram, logoTwitter } from 'ionicons/icons';
import {
  IonHeader,
  IonToolbar,
  IonContent,
  IonPage,
  IonTitle,
  IonButton,
  IonIcon,
} from "@ionic/react"
import React from 'react'
//import './ContactAbout.css';
import { NavButton } from './NavButton'

import { callOutline } from 'ionicons/icons'

const PageTwo: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle class="title">Contact</IonTitle>
          <IonButton slot="end">
            <IonIcon icon={callOutline} />
            <NavButton />
          </IonButton>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen class='main-body'>

        <div className='container'>
          <h2 style={{
              fontSize: "30px",
              fontWeight: "bold",
              fontFamily: "EucrosiaUPC",
              color: "White",
              textTransform: "capitalize",
              marginTop: "100px",
              border: "3px solid rgb(250, 105, 22)"
          }}>
             Click Icon Bellow to visit Our Social Links.</h2><br />
        </div>
        {/*-- fab placed in the center of the content with a list on each side --*/}
        <IonFab vertical="center" horizontal="center" slot="fixed">
          <IonFabButton>
            <IonIcon icon={shareSocialOutline} />
          </IonFabButton>

          <IonFabList side="top">
            <IonFabButton href="https://www.youtube.com/channel/UC-7APxNmLIVU4I-pjG3QvxQ"><IonIcon icon={logoYoutube} /></IonFabButton>
          </IonFabList>
          <IonFabList side="bottom">
            <IonFabButton href="https://www.facebook.com/go2uj/"><IonIcon icon={logoFacebook} /></IonFabButton>
          </IonFabList>
          <IonFabList side="start">
            <IonFabButton href="https://www.instagram.com/university_of_johannesburg/?hl=en"><IonIcon icon={logoInstagram} /></IonFabButton>
          </IonFabList>
          <IonFabList side="end">
            <IonFabButton href="https://twitter.com/mediauj?lang=en"><IonIcon icon={logoTwitter} /></IonFabButton>
          </IonFabList>
        </IonFab>

       {/*<div>
          <h4>
            Email: MnzansiSupport@gmail.com <br />
            Cell Number: 0720191521 <br />

          </h4>
       </div>*/}
      </IonContent>
    </IonPage>
  )
}

export default PageTwo;















