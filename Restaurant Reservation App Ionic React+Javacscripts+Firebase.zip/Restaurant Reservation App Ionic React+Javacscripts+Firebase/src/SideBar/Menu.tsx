import {
    IonMenu,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonList,
    IonMenuToggle,
    IonItem,
    IonLabel,
    IonIcon
} from '@ionic/react'

import {
    callOutline,
    bookOutline,
    homeOutline,
    informationOutline
 } from 'ionicons/icons'

export const Menu = () => {
    return (
        <IonMenu side="start" contentId="main">
            <IonHeader>
                <IonToolbar color="dark">
                    <IonTitle>
                        <IonLabel>Menu</IonLabel> 
                    </IonTitle>
                </IonToolbar>
            </IonHeader>

            <IonContent>
                <IonList>
                    <IonMenuToggle auto-hide="false">
                        <IonItem button routerLink={"/home1"} routerDirection="none">
                            <IonLabel>Home</IonLabel>
                            <IonIcon size="default" icon={homeOutline} />
                        </IonItem>
                    </IonMenuToggle>

                    <IonMenuToggle auto-hide="false">
                        <IonItem button routerLink ={"/page-1"} routerDirection="none">
                            <IonLabel>Bookings</IonLabel>
                            <IonIcon size="default" icon={bookOutline} />
                        </IonItem>

                        <IonItem button routerLink ={"/page-2"} routerDirection="none">
                            <IonLabel>Contacts</IonLabel>
                            <IonIcon icon={callOutline} />
                        </IonItem>

                        <IonItem button routerLink ={"/page-3"} routerDirection="none">
                            <IonLabel>About Us</IonLabel>
                            <IonIcon size="default" icon={informationOutline} />
                        </IonItem>

                    </IonMenuToggle> 
                </IonList>
            </IonContent>
        </IonMenu>
    )
}