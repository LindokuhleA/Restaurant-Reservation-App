import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.starter',
  appName: 'MzansiToGo',
  webDir: 'build',
  bundledWebRuntime: false,
  "server":{
"url": "http://10.10.11.57:3000"




  }
};

export default config;
